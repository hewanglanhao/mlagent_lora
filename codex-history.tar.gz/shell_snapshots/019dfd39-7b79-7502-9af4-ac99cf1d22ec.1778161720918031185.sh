# Snapshot file
# Unset all aliases to avoid conflicts with functions
# Functions

# setopts 3
set -o braceexpand
set -o hashall
set -o interactive-comments

# aliases 0

# exports 34
declare -x BROWSER="/root/.vscode-server/cli/servers/Stable-8b640eef5a6c6089c029249d48efa5c99adf7d51/server/bin/helpers/browser.sh"
declare -x CODEX_INTERNAL_ORIGINATOR_OVERRIDE="codex_vscode"
declare -x DEBUG="release"
declare -x ELECTRON_RUN_AS_NODE="1"
declare -x HOME="/root"
declare -x HTTPS_PROXY="http://127.0.0.1:7897"
declare -x HTTP_PROXY="http://127.0.0.1:7897"
declare -x LESSCLOSE="/usr/bin/lesspipe %s %s"
declare -x LESSOPEN="| /usr/bin/lesspipe %s"
declare -x LOGNAME="root"
declare -x LS_COLORS=""
declare -x MOTD_SHOWN="pam"
declare -x NODE_TLS_REJECT_UNAUTHORIZED="0"
declare -x NVM_BIN="/usr/local/nvm/versions/node/v16.20.2/bin"
declare -x NVM_CD_FLAGS=""
declare -x NVM_DIR="/usr/local/nvm"
declare -x NVM_INC="/usr/local/nvm/versions/node/v16.20.2/include/node"
declare -x PATH="/root/.codex/tmp/arg0/codex-arg0KEdihs:/root/.vscode-server/cli/servers/Stable-8b640eef5a6c6089c029249d48efa5c99adf7d51/server/bin/remote-cli:/usr/local/nvm/versions/node/v16.20.2/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin:/root/.vscode-server/extensions/openai.chatgpt-26.429.30905-linux-x64/bin/linux-x86_64"
declare -x RUST_LOG="warn"
declare -x SHELL="/bin/bash"
declare -x SHLVL="2"
declare -x SSH_CLIENT="10.230.34.181 1614 38221"
declare -x SSH_CONNECTION="10.230.34.181 1614 10.176.34.113 38221"
declare -x USER="root"
declare -x VSCODE_AGENT_FOLDER="/root/.vscode-server"
declare -x VSCODE_CLI_REQUIRE_TOKEN="9d0d30fa-54bf-4597-8ab3-bc882084a3b6"
declare -x VSCODE_CWD="/root"
declare -x VSCODE_ESM_ENTRYPOINT="vs/workbench/api/node/extensionHostProcess"
declare -x VSCODE_HANDLES_SIGPIPE="true"
declare -x VSCODE_HANDLES_UNCAUGHT_ERRORS="true"
declare -x VSCODE_IPC_HOOK_CLI="/tmp/vscode-ipc-65ca37d7-c615-4284-a918-dbb20480e416.sock"
declare -x VSCODE_NLS_CONFIG="{\"userLocale\":\"zh-cn\",\"osLocale\":\"zh-cn\",\"resolvedLanguage\":\"en\",\"defaultMessagesFile\":\"/root/.vscode-server/cli/servers/Stable-8b640eef5a6c6089c029249d48efa5c99adf7d51/server/out/nls.messages.json\",\"locale\":\"zh-cn\",\"availableLanguages\":{}}"
declare -x VSCODE_RECONNECTION_GRACE_TIME="10800000"
declare -x _CUDA_COMPAT_PATH="/usr/local/cuda/compat"
