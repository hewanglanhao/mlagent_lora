# Snapshot file
# Unset all aliases to avoid conflicts with functions
# Functions

# setopts 3
set -o braceexpand
set -o hashall
set -o interactive-comments

# aliases 0

# exports 40
declare -x APPLICATION_INSIGHTS_NO_STATSBEAT="true"
declare -x BROWSER="/root/.vscode-server/cli/servers/Stable-8b640eef5a6c6089c029249d48efa5c99adf7d51/server/bin/helpers/browser.sh"
declare -x CODEX_INTERNAL_ORIGINATOR_OVERRIDE="codex_vscode"
declare -x COPILOT_OTEL_ENABLED="true"
declare -x COPILOT_OTEL_EXPORTER_TYPE="file"
declare -x COPILOT_OTEL_FILE_EXPORTER_PATH="/dev/null"
declare -x DEBUG="release"
declare -x ELECTRON_RUN_AS_NODE="1"
declare -x HOME="/root"
declare -x HTTPS_PROXY="http://127.0.0.1:7897"
declare -x HTTP_PROXY="http://127.0.0.1:7897"
declare -x LESSCLOSE="/usr/bin/lesspipe %s %s"
declare -x LESSOPEN="| /usr/bin/lesspipe %s"
declare -x LOGNAME="root"
declare -x LS_COLORS=""
declare -x MOTD_SHOWN="pam"
declare -x NODE_TLS_REJECT_UNAUTHORIZED="0"
declare -x NVM_BIN="/usr/local/nvm/versions/node/v16.20.2/bin"
declare -x NVM_CD_FLAGS=""
declare -x NVM_DIR="/usr/local/nvm"
declare -x NVM_INC="/usr/local/nvm/versions/node/v16.20.2/include/node"
declare -x OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT="true"
declare -x PATH="/root/.codex/tmp/arg0/codex-arg07DRHrs:/root/.vscode-server/cli/servers/Stable-8b640eef5a6c6089c029249d48efa5c99adf7d51/server/bin/remote-cli:/usr/local/nvm/versions/node/v16.20.2/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin:/root/.vscode-server/extensions/openai.chatgpt-26.506.21252-linux-x64/bin/linux-x86_64"
declare -x RUST_LOG="warn"
declare -x SHELL="/bin/bash"
declare -x SHLVL="2"
declare -x SSH_CLIENT="10.162.193.173 9164 33053"
declare -x SSH_CONNECTION="10.162.193.173 9164 10.176.34.113 33053"
declare -x USER="root"
declare -x VSCODE_AGENT_FOLDER="/root/.vscode-server"
declare -x VSCODE_CLI_REQUIRE_TOKEN="1b6583c6-ffeb-41ef-89a5-1921008463a1"
declare -x VSCODE_CWD="/root"
declare -x VSCODE_ESM_ENTRYPOINT="vs/workbench/api/node/extensionHostProcess"
declare -x VSCODE_HANDLES_SIGPIPE="true"
declare -x VSCODE_HANDLES_UNCAUGHT_ERRORS="true"
declare -x VSCODE_IPC_HOOK_CLI="/tmp/vscode-ipc-6a6abdec-cba9-44ee-92ad-74ec0af6a66c.sock"
declare -x VSCODE_L10N_BUNDLE_LOCATION="vscode-local:/c%3A/Users/lizihan/.vscode/extensions/ms-ceintl.vscode-language-pack-zh-hans-1.118.2026050120/translations/extensions/vscode.markdown-language-features.i18n.json"
declare -x VSCODE_NLS_CONFIG="{\"userLocale\":\"zh-cn\",\"osLocale\":\"zh-cn\",\"resolvedLanguage\":\"en\",\"defaultMessagesFile\":\"/root/.vscode-server/cli/servers/Stable-8b640eef5a6c6089c029249d48efa5c99adf7d51/server/out/nls.messages.json\",\"locale\":\"zh-cn\",\"availableLanguages\":{}}"
declare -x VSCODE_RECONNECTION_GRACE_TIME="10800000"
declare -x _CUDA_COMPAT_PATH="/usr/local/cuda/compat"
